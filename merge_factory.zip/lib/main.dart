
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';

const bg = Color(0xFF0B1020);
const panel = Color(0xFF151C32);
const accent = Color(0xFF7C5CFF);
const cyan = Color(0xFF36D1DC);
const pink = Color(0xFFFF5EA8);
const green = Color(0xFF42E695);
const yellow = Color(0xFFFFD166);

TextStyle titleStyle(double size) => GoogleFonts.poppins(
  fontSize: size, fontWeight: FontWeight.w800, color: Colors.white,
);
TextStyle bodyStyle(double size) => GoogleFonts.poppins(
  fontSize: size, fontWeight: FontWeight.w500, color: Colors.white70,
);

class GameShell extends StatelessWidget {
  final String title;
  final String subtitle;
  final Widget child;
  final VoidCallback? onReset;
  const GameShell({super.key, required this.title, required this.subtitle, required this.child, this.onReset});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bg,
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 560),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(18, 16, 18, 18),
              child: Column(
                children: [
                  Row(children: [
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(title, style: titleStyle(26)),
                      const SizedBox(height: 2),
                      Text(subtitle, style: bodyStyle(12)),
                    ])),
                    if (onReset != null) IconButton(
                      onPressed: onReset,
                      icon: const Icon(Icons.refresh_rounded, color: Colors.white70),
                    )
                  ]),
                  const SizedBox(height: 14),
                  Expanded(child: child),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class StatPill extends StatelessWidget {
  final String label;
  final String value;
  const StatPill({super.key, required this.label, required this.value});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 9),
    decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(16)),
    child: Column(children: [
      Text(value, style: titleStyle(18)),
      Text(label, style: bodyStyle(10)),
    ]),
  );
}

Future<void> saveInt(String key, int value) async {
  final p = await SharedPreferences.getInstance();
  await p.setInt(key, value);
}
Future<int> loadInt(String key) async {
  final p = await SharedPreferences.getInstance();
  return p.getInt(key) ?? 0;
}

void main()=>runApp(const MergeApp());
class MergeApp extends StatelessWidget{const MergeApp({super.key});@override Widget build(BuildContext c)=>MaterialApp(debugShowCheckedModeBanner:false,theme:ThemeData.dark(useMaterial3:true),home:const MergeGame());}
class _MergeState extends State<MergeGame>{List<int> cells=List.filled(12,0);int coins=0,best=0;@override void initState(){super.initState();_spawn();loadInt('merge_best').then((v)=>setState(()=>best=v));}
void _spawn(){final e=cells.indexWhere((v)=>v==0);if(e>=0)cells[e]=Random().nextInt(2)+1;}
void _tap(int i){if(cells[i]==0)return;final same=cells.indexWhere((v)=>v==cells[i]&&v!=0&&v!=cells[i]);setState((){coins+=cells[i]*5;_spawn();});}
@override Widget build(BuildContext c)=>GameShell(title:'Merge Factory',subtitle:'Tap machines to produce coins. Build the factory over time.',onReset:()=>setState(()=>cells=List.filled(12,0)),child:Column(children:[Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[StatPill(label:'Coins',value:'$coins'),StatPill(label:'Best',value:'$best')]),const SizedBox(height:14),Expanded(child:GridView.builder(gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:3,crossAxisSpacing:10,mainAxisSpacing:10),itemCount:cells.length,itemBuilder:(c,i){final v=cells[i];return GestureDetector(onTap:()=>_tap(i),child:Container(decoration:BoxDecoration(color:v==0?panel:accent.withOpacity(.18),borderRadius:BorderRadius.circular(22),border:Border.all(color:v==0?Colors.white10:accent.withOpacity(.5))),child:Center(child:v==0?const Icon(Icons.add_rounded,color:Colors.white24,size:28):Column(mainAxisAlignment:MainAxisAlignment.center,children:[Icon(v==1?Icons.precision_manufacturing_rounded:Icons.factory_rounded,color:v==1?cyan:yellow,size:38),const SizedBox(height:5),Text('LV $v',style:titleStyle(11))]))));})),Text('Collect • upgrade • repeat',style:bodyStyle(13))]));}
class MergeGame extends StatefulWidget{const MergeGame({super.key});@override State<MergeGame> createState()=>_MergeState();}
