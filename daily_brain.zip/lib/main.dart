
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';

const bg = Color(0xFF0B1020);
const panel = Color(0xFF151C32);
const accent = Color(0xFF7C5CFF);
const cyan = Color(0xFF36D1DC);
const pink = Color(0xFFFF5EA8);
const green = Color(0xFF42E695);
const yellow = Color(0xFFFFD166);

TextStyle titleStyle(double size) => GoogleFonts.poppins(
  fontSize: size, fontWeight: FontWeight.w800, color: Colors.white,
);
TextStyle bodyStyle(double size) => GoogleFonts.poppins(
  fontSize: size, fontWeight: FontWeight.w500, color: Colors.white70,
);

class GameShell extends StatelessWidget {
  final String title;
  final String subtitle;
  final Widget child;
  final VoidCallback? onReset;
  const GameShell({super.key, required this.title, required this.subtitle, required this.child, this.onReset});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bg,
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 560),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(18, 16, 18, 18),
              child: Column(
                children: [
                  Row(children: [
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(title, style: titleStyle(26)),
                      const SizedBox(height: 2),
                      Text(subtitle, style: bodyStyle(12)),
                    ])),
                    if (onReset != null) IconButton(
                      onPressed: onReset,
                      icon: const Icon(Icons.refresh_rounded, color: Colors.white70),
                    )
                  ]),
                  const SizedBox(height: 14),
                  Expanded(child: child),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class StatPill extends StatelessWidget {
  final String label;
  final String value;
  const StatPill({super.key, required this.label, required this.value});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 9),
    decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(16)),
    child: Column(children: [
      Text(value, style: titleStyle(18)),
      Text(label, style: bodyStyle(10)),
    ]),
  );
}

Future<void> saveInt(String key, int value) async {
  final p = await SharedPreferences.getInstance();
  await p.setInt(key, value);
}
Future<int> loadInt(String key) async {
  final p = await SharedPreferences.getInstance();
  return p.getInt(key) ?? 0;
}

void main()=>runApp(const BrainApp());
class BrainApp extends StatelessWidget{const BrainApp({super.key});@override Widget build(BuildContext c)=>MaterialApp(debugShowCheckedModeBanner:false,theme:ThemeData.dark(useMaterial3:true),home:const BrainGame());}
class _BrainState extends State<BrainGame>{final r=Random();int q=0,score=0,a=7,b=3,correct=10;String pattern='2, 4, 8, 16, ?';@override void initState(){super.initState();_new();}
void _new(){a=r.nextInt(12)+2;b=r.nextInt(9)+2;correct=a*b;q++;}
void _answer(int v){if(v==correct)score+=100;setState(_new);}
@override Widget build(BuildContext c)=>GameShell(title:'Daily Brain',subtitle:'Fast mental challenges. Keep your streak alive.',onReset:()=>setState(() {q=0;score=0;_new();}),child:Column(children:[Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[StatPill(label:'Question',value:'$q'),StatPill(label:'Score',value:'$score')]),const SizedBox(height:30),Text('$a × $b = ?',style:titleStyle(42)),const SizedBox(height:20),Expanded(child:GridView.count(crossAxisCount:2,mainAxisSpacing:12,crossAxisSpacing:12,children:(() {final vals=[correct,correct+2,correct-3,correct+5]..shuffle(); return List.generate(4,(i){final v=vals[i];return ElevatedButton(onPressed:()=>_answer(v),style:ElevatedButton.styleFrom(backgroundColor:panel,foregroundColor:Colors.white,shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(22))),child:Text('$v',style:titleStyle(24))));})()) ,Text('More modes can be added: memory • reaction • patterns',style:bodyStyle(12))]));}
class BrainGame extends StatefulWidget{const BrainGame({super.key});@override State<BrainGame> createState()=>_BrainState();}
