
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';

const bg = Color(0xFF0B1020);
const panel = Color(0xFF151C32);
const accent = Color(0xFF7C5CFF);
const cyan = Color(0xFF36D1DC);
const pink = Color(0xFFFF5EA8);
const green = Color(0xFF42E695);
const yellow = Color(0xFFFFD166);

TextStyle titleStyle(double size) => GoogleFonts.poppins(
  fontSize: size, fontWeight: FontWeight.w800, color: Colors.white,
);
TextStyle bodyStyle(double size) => GoogleFonts.poppins(
  fontSize: size, fontWeight: FontWeight.w500, color: Colors.white70,
);

class GameShell extends StatelessWidget {
  final String title;
  final String subtitle;
  final Widget child;
  final VoidCallback? onReset;
  const GameShell({super.key, required this.title, required this.subtitle, required this.child, this.onReset});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bg,
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 560),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(18, 16, 18, 18),
              child: Column(
                children: [
                  Row(children: [
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(title, style: titleStyle(26)),
                      const SizedBox(height: 2),
                      Text(subtitle, style: bodyStyle(12)),
                    ])),
                    if (onReset != null) IconButton(
                      onPressed: onReset,
                      icon: const Icon(Icons.refresh_rounded, color: Colors.white70),
                    )
                  ]),
                  const SizedBox(height: 14),
                  Expanded(child: child),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class StatPill extends StatelessWidget {
  final String label;
  final String value;
  const StatPill({super.key, required this.label, required this.value});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 9),
    decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(16)),
    child: Column(children: [
      Text(value, style: titleStyle(18)),
      Text(label, style: bodyStyle(10)),
    ]),
  );
}

Future<void> saveInt(String key, int value) async {
  final p = await SharedPreferences.getInstance();
  await p.setInt(key, value);
}
Future<int> loadInt(String key) async {
  final p = await SharedPreferences.getInstance();
  return p.getInt(key) ?? 0;
}

void main()=>runApp(const FixApp());
class FixApp extends StatelessWidget{const FixApp({super.key});@override Widget build(BuildContext c)=>MaterialApp(debugShowCheckedModeBanner:false,theme:ThemeData.dark(useMaterial3:true),home:const FixGame());}
class _FixState extends State<FixGame>{int task=0,done=0;double progress=0;final tasks=['Clean the window','Tighten the screw','Paint the wall','Repair the pipe','Polish the table'];void _tap(){setState(()=>progress=min(1,progress+.17));if(progress>=1){setState((){done++;task=(task+1)%tasks.length;progress=0;});}}
@override Widget build(BuildContext c)=>GameShell(title:'Satisfying Fix',subtitle:'Tiny tasks. Big visual feedback.',onReset:()=>setState(() {task=0;done=0;progress=0;}),child:Column(children:[Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[StatPill(label:'Task',value:'${task+1}/${tasks.length}'),StatPill(label:'Fixed',value:'$done')]),const SizedBox(height:30),Text(tasks[task],style:titleStyle(24),textAlign:TextAlign.center),const SizedBox(height:18),Expanded(child:GestureDetector(onTap:_tap,child:AnimatedContainer(duration:const Duration(milliseconds:220),decoration:BoxDecoration(color:panel,borderRadius:BorderRadius.circular(32)),child:Center(child:Column(mainAxisSize:MainAxisSize.min,children:[Icon([Icons.cleaning_services_rounded,Icons.build_rounded,Icons.format_paint_rounded,Icons.plumbing_rounded,Icons.auto_awesome_rounded][task],size:96,color:[cyan,accent,pink,yellow,green][task]),const SizedBox(height:24),Text('${(progress*100).round()}%',style:titleStyle(30))]))))),const SizedBox(height:16),LinearProgressIndicator(value:progress,minHeight:10,borderRadius:BorderRadius.circular(10)),const SizedBox(height:10),Text('Tap repeatedly to finish',style:bodyStyle(13))]));}
class FixGame extends StatefulWidget{const FixGame({super.key});@override State<FixGame> createState()=>_FixState();}
