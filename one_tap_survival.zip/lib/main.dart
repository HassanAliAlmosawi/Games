
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';

const bg = Color(0xFF0B1020);
const panel = Color(0xFF151C32);
const accent = Color(0xFF7C5CFF);
const cyan = Color(0xFF36D1DC);
const pink = Color(0xFFFF5EA8);
const green = Color(0xFF42E695);
const yellow = Color(0xFFFFD166);

TextStyle titleStyle(double size) => GoogleFonts.poppins(
  fontSize: size, fontWeight: FontWeight.w800, color: Colors.white,
);
TextStyle bodyStyle(double size) => GoogleFonts.poppins(
  fontSize: size, fontWeight: FontWeight.w500, color: Colors.white70,
);

class GameShell extends StatelessWidget {
  final String title;
  final String subtitle;
  final Widget child;
  final VoidCallback? onReset;
  const GameShell({super.key, required this.title, required this.subtitle, required this.child, this.onReset});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bg,
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 560),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(18, 16, 18, 18),
              child: Column(
                children: [
                  Row(children: [
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(title, style: titleStyle(26)),
                      const SizedBox(height: 2),
                      Text(subtitle, style: bodyStyle(12)),
                    ])),
                    if (onReset != null) IconButton(
                      onPressed: onReset,
                      icon: const Icon(Icons.refresh_rounded, color: Colors.white70),
                    )
                  ]),
                  const SizedBox(height: 14),
                  Expanded(child: child),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class StatPill extends StatelessWidget {
  final String label;
  final String value;
  const StatPill({super.key, required this.label, required this.value});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 9),
    decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(16)),
    child: Column(children: [
      Text(value, style: titleStyle(18)),
      Text(label, style: bodyStyle(10)),
    ]),
  );
}

Future<void> saveInt(String key, int value) async {
  final p = await SharedPreferences.getInstance();
  await p.setInt(key, value);
}
Future<int> loadInt(String key) async {
  final p = await SharedPreferences.getInstance();
  return p.getInt(key) ?? 0;
}

void main()=>runApp(const SurvivalApp());
class SurvivalApp extends StatelessWidget{const SurvivalApp({super.key});@override Widget build(BuildContext c)=>MaterialApp(debugShowCheckedModeBanner:false,theme:ThemeData.dark(useMaterial3:true),home:const SurvivalGame());}
class _SurvivalState extends State<SurvivalGame> with SingleTickerProviderStateMixin{late AnimationController ctrl;double y=0,vy=0;int score=0,best=0;bool alive=true;@override void initState(){super.initState();loadInt('survival_best').then((v)=>setState(()=>best=v));ctrl=AnimationController(vsync:this,duration:const Duration(milliseconds:16))..addListener(_tick)..repeat();}
void _tick(){if(!alive)return;setState((){vy+=.55;y+=vy;score++;if(y>1){alive=false;if(score>best){best=score;saveInt('survival_best',best);}}});}
void jump(){if(!alive){setState(() {alive=true;y=.5;vy=0;score=0;});return;}setState(()=>vy=-9);}
@override void dispose(){ctrl.dispose();super.dispose();}
@override Widget build(BuildContext c)=>GameShell(title:'One Tap Survival',subtitle:'Tap anywhere to jump. Survive as long as possible.',onReset:()=>setState(() {alive=true;y=.5;vy=0;score=0;}),child:Column(children:[Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[StatPill(label:'Score',value:'$score'),StatPill(label:'Best',value:'$best')]),const SizedBox(height:14),Expanded(child:GestureDetector(onTap:jump,child:CustomPaint(painter:SurvivalPainter(y:y,score:score,alive:alive),child:const SizedBox.expand()))),const SizedBox(height:10),Text(alive?'TAP TO JUMP':'GAME OVER • TAP TO RESTART',style:bodyStyle(13))]));}
class SurvivalPainter extends CustomPainter{final double y;final int score;final bool alive;SurvivalPainter({required this.y,required this.score,required this.alive});@override void paint(Canvas c,Size s){final p=Paint();p.color=panel;c.drawRRect(RRect.fromRectAndRadius(Offset.zero&s,const Radius.circular(28)),p);p.color=accent;final px=s.width*.22,py=s.height*(.65+y*.35);c.drawCircle(Offset(px,py),22,p);p.color=pink;final ox=s.width*.72,oy=s.height*.78-(score%140)*.003*s.height;c.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(ox,oy,26,50),const Radius.circular(8)),p);p.color=Colors.white24;c.drawRect(Rect.fromLTWH(0,s.height*.82,s.width,2),p);if(!alive){TextPainter(text:TextSpan(text:'GAME OVER',style:titleStyle(30)),textDirection:TextDirection.ltr)..layout()..paint(c,Offset(s.width/2-80,s.height*.38));}}@override bool shouldRepaint(covariant SurvivalPainter old)=>true;}
class SurvivalGame extends StatefulWidget{const SurvivalGame({super.key});@override State<SurvivalGame> createState()=>_SurvivalState();}
