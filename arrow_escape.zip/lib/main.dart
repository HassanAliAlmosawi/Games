
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';

const bg = Color(0xFF0B1020);
const panel = Color(0xFF151C32);
const accent = Color(0xFF7C5CFF);
const cyan = Color(0xFF36D1DC);
const pink = Color(0xFFFF5EA8);
const green = Color(0xFF42E695);
const yellow = Color(0xFFFFD166);

TextStyle titleStyle(double size) => GoogleFonts.poppins(
  fontSize: size, fontWeight: FontWeight.w800, color: Colors.white,
);
TextStyle bodyStyle(double size) => GoogleFonts.poppins(
  fontSize: size, fontWeight: FontWeight.w500, color: Colors.white70,
);

class GameShell extends StatelessWidget {
  final String title;
  final String subtitle;
  final Widget child;
  final VoidCallback? onReset;
  const GameShell({super.key, required this.title, required this.subtitle, required this.child, this.onReset});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bg,
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 560),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(18, 16, 18, 18),
              child: Column(
                children: [
                  Row(children: [
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(title, style: titleStyle(26)),
                      const SizedBox(height: 2),
                      Text(subtitle, style: bodyStyle(12)),
                    ])),
                    if (onReset != null) IconButton(
                      onPressed: onReset,
                      icon: const Icon(Icons.refresh_rounded, color: Colors.white70),
                    )
                  ]),
                  const SizedBox(height: 14),
                  Expanded(child: child),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class StatPill extends StatelessWidget {
  final String label;
  final String value;
  const StatPill({super.key, required this.label, required this.value});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 9),
    decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(16)),
    child: Column(children: [
      Text(value, style: titleStyle(18)),
      Text(label, style: bodyStyle(10)),
    ]),
  );
}

Future<void> saveInt(String key, int value) async {
  final p = await SharedPreferences.getInstance();
  await p.setInt(key, value);
}
Future<int> loadInt(String key) async {
  final p = await SharedPreferences.getInstance();
  return p.getInt(key) ?? 0;
}

void main()=>runApp(const ArrowApp());
class ArrowApp extends StatelessWidget{const ArrowApp({super.key});@override Widget build(BuildContext c)=>MaterialApp(debugShowCheckedModeBanner:false,theme:ThemeData.dark(useMaterial3:true),home:const ArrowGame());}
class _ArrowGameState extends State<ArrowGame>{
 final n=6; List<int> dirs=[]; int level=1, moves=0,best=0;
 @override void initState(){super.initState();loadInt('arrow_best').then((v)=>setState(()=>best=v));_reset();}
 void _reset(){final r=Random(level*999);dirs=List.generate(n*n,(_)=>r.nextInt(4));moves=0;}
 bool _canExit(int i){int x=i%n,y=i~/n,d=dirs[i];return d==0&&y==0||d==1&&x==n-1||d==2&&y==n-1||d==3&&x==0;}
 void _tap(int i){if(!_canExit(i))return;setState((){dirs[i]=-1;moves++;});if(dirs.every((x)=>x<0)){level++; if(level>best){best=level;saveInt('arrow_best',best);}Future.delayed(const Duration(milliseconds:350),()=>setState(_reset));}}
 IconData _icon(int d)=>[Icons.keyboard_arrow_up_rounded,Icons.keyboard_arrow_right_rounded,Icons.keyboard_arrow_down_rounded,Icons.keyboard_arrow_left_rounded][d];
 @override Widget build(BuildContext c)=>GameShell(title:'Arrow Escape',subtitle:'Only arrows that can leave the board are safe to tap.',onReset:()=>setState(_reset),child:Column(children:[
 Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[StatPill(label:'Level',value:'$level'),StatPill(label:'Moves',value:'$moves'),StatPill(label:'Best',value:'$best')]),const SizedBox(height:18),
 Expanded(child:AspectRatio(aspectRatio:1,child:Container(padding:const EdgeInsets.all(8),decoration:BoxDecoration(color:panel,borderRadius:BorderRadius.circular(28)),child:GridView.builder(physics:const NeverScrollableScrollPhysics(),gridDelegate:SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:n,crossAxisSpacing:5,mainAxisSpacing:5),itemCount:n*n,itemBuilder:(c,i)=>GestureDetector(onTap:()=>_tap(i),child:AnimatedContainer(duration:const Duration(milliseconds:180),decoration:BoxDecoration(color:dirs[i]<0?Colors.transparent:accent.withOpacity(.14),borderRadius:BorderRadius.circular(12)),child:dirs[i]<0?const SizedBox():Icon(_icon(dirs[i]),color:cyan,size:30))))))),const SizedBox(height:14),Text('Level $level • Clear the board',style:bodyStyle(13))]));}
