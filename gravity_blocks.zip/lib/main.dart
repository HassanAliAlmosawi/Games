
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';

const bg = Color(0xFF0B1020);
const panel = Color(0xFF151C32);
const accent = Color(0xFF7C5CFF);
const cyan = Color(0xFF36D1DC);
const pink = Color(0xFFFF5EA8);
const green = Color(0xFF42E695);
const yellow = Color(0xFFFFD166);

TextStyle titleStyle(double size) => GoogleFonts.poppins(
  fontSize: size, fontWeight: FontWeight.w800, color: Colors.white,
);
TextStyle bodyStyle(double size) => GoogleFonts.poppins(
  fontSize: size, fontWeight: FontWeight.w500, color: Colors.white70,
);

class GameShell extends StatelessWidget {
  final String title;
  final String subtitle;
  final Widget child;
  final VoidCallback? onReset;
  const GameShell({super.key, required this.title, required this.subtitle, required this.child, this.onReset});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bg,
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 560),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(18, 16, 18, 18),
              child: Column(
                children: [
                  Row(children: [
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(title, style: titleStyle(26)),
                      const SizedBox(height: 2),
                      Text(subtitle, style: bodyStyle(12)),
                    ])),
                    if (onReset != null) IconButton(
                      onPressed: onReset,
                      icon: const Icon(Icons.refresh_rounded, color: Colors.white70),
                    )
                  ]),
                  const SizedBox(height: 14),
                  Expanded(child: child),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class StatPill extends StatelessWidget {
  final String label;
  final String value;
  const StatPill({super.key, required this.label, required this.value});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 9),
    decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(16)),
    child: Column(children: [
      Text(value, style: titleStyle(18)),
      Text(label, style: bodyStyle(10)),
    ]),
  );
}

Future<void> saveInt(String key, int value) async {
  final p = await SharedPreferences.getInstance();
  await p.setInt(key, value);
}
Future<int> loadInt(String key) async {
  final p = await SharedPreferences.getInstance();
  return p.getInt(key) ?? 0;
}

void main()=>runApp(const GravityApp());
class GravityApp extends StatelessWidget{const GravityApp({super.key});@override Widget build(BuildContext c)=>MaterialApp(debugShowCheckedModeBanner:false,theme:ThemeData.dark(useMaterial3:true),home:const GravityGame());}
class _GravityState extends State<GravityGame>{final n=8;List<List<int>> g=[];int score=0,best=0;@override void initState(){super.initState();_new();loadInt('gravity_best').then((v)=>setState(()=>best=v));}
void _new(){g=List.generate(n,(_)=>List.filled(n,0));}
void _place(){final r=Random();final col=r.nextInt(n);for(int y=n-1;y>=0;y--){if(g[y][col]==0){g[y][col]=r.nextInt(4)+1;break;}}for(int y=0;y<n;y++){if(g[y].every((v)=>v!=0)){g.removeAt(y);g.insert(0,List.filled(n,0));score+=100;}}if(score>best){best=score;saveInt('gravity_best',best);}}
@override Widget build(BuildContext c)=>GameShell(title:'Gravity Blocks',subtitle:'Tap a column to drop a block. Complete rows for bonus points.',onReset:()=>setState(()=>{score=0;_new();}),child:Column(children:[Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[StatPill(label:'Score',value:'$score'),StatPill(label:'Best',value:'$best')]),const SizedBox(height:14),Expanded(child:GridView.builder(physics:const NeverScrollableScrollPhysics(),gridDelegate:SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:n,crossAxisSpacing:5,mainAxisSpacing:5),itemCount:n*n,itemBuilder:(c,i){final y=i~/n,x=i%n,v=g[y][x];return GestureDetector(onTap:()=>setState(_place),child:Container(decoration:BoxDecoration(color:v==0?panel:[accent,cyan,pink,yellow][v-1].withOpacity(.82),borderRadius:BorderRadius.circular(8))))})),const SizedBox(height:10),Text('Tap anywhere to play',style:bodyStyle(13))]));}
