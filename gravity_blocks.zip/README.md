# Gravity Blocks

A polished Flutter MVP generated for rapid testing and iteration.

## Run

```bash
flutter pub get
flutter run
```

For Android:

```bash
flutter build apk --release
```

## Notes

- This project intentionally avoids hard-coded AdMob IDs. Add `google_mobile_ads` and your own app/ad unit IDs after validating the gameplay.
- Progress/high score is stored locally with SharedPreferences.
- The game is designed to be playable immediately with touch/mouse input.
- Replace the placeholder monetization hooks only after you have tested retention and crash-free behavior.
