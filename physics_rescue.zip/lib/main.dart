
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';

const bg = Color(0xFF0B1020);
const panel = Color(0xFF151C32);
const accent = Color(0xFF7C5CFF);
const cyan = Color(0xFF36D1DC);
const pink = Color(0xFFFF5EA8);
const green = Color(0xFF42E695);
const yellow = Color(0xFFFFD166);

TextStyle titleStyle(double size) => GoogleFonts.poppins(
  fontSize: size, fontWeight: FontWeight.w800, color: Colors.white,
);
TextStyle bodyStyle(double size) => GoogleFonts.poppins(
  fontSize: size, fontWeight: FontWeight.w500, color: Colors.white70,
);

class GameShell extends StatelessWidget {
  final String title;
  final String subtitle;
  final Widget child;
  final VoidCallback? onReset;
  const GameShell({super.key, required this.title, required this.subtitle, required this.child, this.onReset});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bg,
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 560),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(18, 16, 18, 18),
              child: Column(
                children: [
                  Row(children: [
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(title, style: titleStyle(26)),
                      const SizedBox(height: 2),
                      Text(subtitle, style: bodyStyle(12)),
                    ])),
                    if (onReset != null) IconButton(
                      onPressed: onReset,
                      icon: const Icon(Icons.refresh_rounded, color: Colors.white70),
                    )
                  ]),
                  const SizedBox(height: 14),
                  Expanded(child: child),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class StatPill extends StatelessWidget {
  final String label;
  final String value;
  const StatPill({super.key, required this.label, required this.value});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 9),
    decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(16)),
    child: Column(children: [
      Text(value, style: titleStyle(18)),
      Text(label, style: bodyStyle(10)),
    ]),
  );
}

Future<void> saveInt(String key, int value) async {
  final p = await SharedPreferences.getInstance();
  await p.setInt(key, value);
}
Future<int> loadInt(String key) async {
  final p = await SharedPreferences.getInstance();
  return p.getInt(key) ?? 0;
}

void main()=>runApp(const RescueApp());
class RescueApp extends StatelessWidget{const RescueApp({super.key});@override Widget build(BuildContext c)=>MaterialApp(debugShowCheckedModeBanner:false,theme:ThemeData.dark(useMaterial3:true),home:const RescueGame());}
class _RescueGameState extends State<RescueGame> with SingleTickerProviderStateMixin{
 late AnimationController ctrl; double shield=.5; int level=1,score=0; bool running=false; List<double> rocks=[];
 @override void initState(){super.initState();ctrl=AnimationController(vsync:this,duration:const Duration(seconds:8))..addListener(_tick);_start();}
 void _start(){rocks=List.generate(7,(i)=>Random().nextDouble());running=true;ctrl.forward(from:0);}
 void _tick(){if(!mounted||!running)return;setState((){});if(ctrl.value>=1){running=false;score+=100;level++;}}
 @override void dispose(){ctrl.dispose();super.dispose();}
 @override Widget build(BuildContext c)=>GameShell(title:'Physics Rescue',subtitle:'Move the shield horizontally and survive the falling rocks.',onReset:()=>setState(_start),child:Column(children:[
 Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[StatPill(label:'Level',value:'$level'),StatPill(label:'Score',value:'$score')]),const SizedBox(height:12),
 Expanded(child:GestureDetector(onPanUpdate:(d)=>setState(()=>shield=(shield+d.delta.dx/300).clamp(.12,.88)),child:CustomPaint(painter:RescuePainter(t:ctrl.value,shield:shield,rocks:rocks),child:const SizedBox.expand()))),
 const SizedBox(height:10),Text('← drag shield →',style:bodyStyle(13)),const SizedBox(height:8)
 ]));}
class RescuePainter extends CustomPainter{
 final double t,shield;final List<double> rocks;RescuePainter({required this.t,required this.shield,required this.rocks});
 @override void paint(Canvas c,Size s){final p=Paint();p.color=panel;c.drawRRect(RRect.fromRectAndRadius(Offset.zero& s,const Radius.circular(28)),p);
 p.color=green;c.drawCircle(Offset(s.width*.5,s.height*.78),24,p);p.color=Colors.white;c.drawCircle(Offset(s.width*.5-7,s.height*.77),3,p);c.drawCircle(Offset(s.width*.5+7,s.height*.77),3,p);
 p.color=cyan;final y=s.height*.69;c.drawRRect(RRect.fromRectAndRadius(Rect.fromCenter(center:Offset(shield*s.width,y),width:110,height:15),const Radius.circular(8)),p);
 for(final x in rocks){final yy=t*s.height*.85;final xx=x*s.width;p.color=pink;c.drawCircle(Offset(xx,yy),12,p);}
 }
 @override bool shouldRepaint(covariant RescuePainter old)=>true;
}
