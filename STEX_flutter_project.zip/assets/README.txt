Reserved for future audio, sprites, fonts and production art.
