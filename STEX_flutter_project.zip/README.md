# STEX — Run Riyadh. Dodge the Future.

A polished Flutter infinite-runner prototype for iOS and Android.

## Run
```bash
flutter pub get
flutter run
```

## Controls
- Tap: jump
- Swipe left/right: change lane
- Pause: top-right button

## Included
- Futuristic Riyadh-inspired neon visual system
- Infinite 3-lane runner
- Progressive speed/difficulty
- Jump physics and lane switching
- Obstacles with different heights
- Score, distance and persistent best score
- Countdown, pause, game-over and help/settings screens
- Responsive UI for phone aspect ratios
- No external image/audio dependency required; the game uses Flutter CustomPainter visuals

## Suggested production upgrades
Add real character sprites/3D models, audio, haptics, analytics, ads/IAP, missions, skins, leaderboards and cloud save behind the existing modular game state.
