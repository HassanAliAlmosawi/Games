
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const StexApp());

class StexApp extends StatelessWidget {
  const StexApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'STEX',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF050812),
        fontFamily: 'Arial',
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF00F5FF),
          brightness: Brightness.dark,
        ),
      ),
      home: const StexShell(),
    );
  }
}

enum Screen { home, game, pause, over, help, settings }

class StexShell extends StatefulWidget {
  const StexShell({super.key});
  @override State<StexShell> createState() => _StexShellState();
}

class _StexShellState extends State<StexShell> {
  Screen screen = Screen.home;
  int best = 0;

  @override
  void initState() {
    super.initState();
    _loadBest();
  }

  Future<void> _loadBest() async {
    final p = await SharedPreferences.getInstance();
    setState(() => best = p.getInt('best') ?? 0);
  }

  Future<void> _saveBest(int score) async {
    if (score <= best) return;
    final p = await SharedPreferences.getInstance();
    await p.setInt('best', score);
    setState(() => best = score);
  }

  void start() => setState(() => screen = Screen.game);
  void home() => setState(() => screen = Screen.home);

  @override
  Widget build(BuildContext context) {
    Widget child;
    switch (screen) {
      case Screen.home:
        child = HomeScreen(best: best, onPlay: start,
          onHelp: () => setState(() => screen = Screen.help),
          onSettings: () => setState(() => screen = Screen.settings));
      case Screen.game:
        child = GameScreen(best: best,
          onPause: () => setState(() => screen = Screen.pause),
          onGameOver: (score) async {
            await _saveBest(score);
            if (mounted) setState(() => screen = Screen.over);
          });
      case Screen.pause:
        child = PauseScreen(
          onResume: () => setState(() => screen = Screen.game),
          onRestart: start, onHome: home,
          onSettings: () => setState(() => screen = Screen.settings));
      case Screen.over:
        child = GameOverScreen(
          score: _lastScore, distance: _lastDistance, best: best,
          onAgain: start, onHome: home);
      case Screen.help:
        child = HelpScreen(onBack: home);
      case Screen.settings:
        child = SettingsScreen(onBack: home);
    }
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 420),
      switchInCurve: Curves.easeOutCubic,
      child: KeyedSubtree(key: ValueKey(screen), child: child),
    );
  }

  int _lastScore = 0;
  int _lastDistance = 0;
}

class NeonBackdrop extends StatelessWidget {
  final Widget child;
  const NeonBackdrop({super.key, required this.child});
  @override
  Widget build(BuildContext context) => Stack(
    fit: StackFit.expand,
    children: [
      CustomPaint(painter: RiyadhPainter()),
      child,
    ],
  );
}

class RiyadhPainter extends CustomPainter {
  @override
  void paint(Canvas c, Size s) {
    final bg = Paint()..shader = LinearGradient(
      begin: Alignment.topCenter, end: Alignment.bottomCenter,
      colors: const [Color(0xFF030617), Color(0xFF071329), Color(0xFF02050C)],
    ).createShader(Offset.zero & s);
    c.drawRect(Offset.zero & s, bg);

    final horizon = s.height * .62;
    final glow = Paint()
      ..shader = RadialGradient(colors: [
        const Color(0xFF00E5FF).withOpacity(.18),
        Colors.transparent
      ]).createShader(Rect.fromCircle(center: Offset(s.width*.55,horizon), radius: s.width*.7));
    c.drawCircle(Offset(s.width*.55,horizon), s.width*.7, glow);

    final city = Paint()..style=PaintingStyle.fill;
    final rnd = math.Random(17);
    double x=0;
    while(x<s.width){
      final w=28+rnd.nextDouble()*55;
      final h=30+rnd.nextDouble()*145;
      city.color=Color.lerp(const Color(0xFF07101D), const Color(0xFF111B2A), rnd.nextDouble())!;
      c.drawRect(Rect.fromLTWH(x,horizon-h,w,h),city);
      final windows=Paint()..color=const Color(0xFF00E5FF).withOpacity(.18);
      for(double wy=horizon-h+12;wy<horizon-8;wy+=18){
        if(rnd.nextBool()) c.drawRect(Rect.fromLTWH(x+7,wy,4,7),windows);
        if(rnd.nextBool()) c.drawRect(Rect.fromLTWH(x+w-11,wy,4,7),windows);
      }
      x+=w+5;
    }

    // Riyadh-inspired geometric tower silhouette.
    final tower = Path()
      ..moveTo(s.width*.72,horizon)
      ..lineTo(s.width*.72,horizon-170)
      ..lineTo(s.width*.76,horizon-225)
      ..lineTo(s.width*.80,horizon-170)
      ..lineTo(s.width*.80,horizon)
      ..close();
    c.drawPath(tower, Paint()..color=const Color(0xFF0C1727));
    c.drawLine(Offset(s.width*.76,horizon-225),Offset(s.width*.76,horizon-250),
      Paint()..color=const Color(0xFF00F5FF)..strokeWidth=2);

    final road = Paint()..color=const Color(0xFF070B13);
    final roadPath=Path()
      ..moveTo(s.width*.32,s.height)
      ..lineTo(s.width*.45,horizon)
      ..lineTo(s.width*.55,horizon)
      ..lineTo(s.width*.68,s.height)
      ..close();
    c.drawPath(roadPath,road);

    final grid=Paint()..color=const Color(0xFF00D9FF).withOpacity(.16)..strokeWidth=1;
    for(int i=0;i<14;i++){
      final y=horizon+math.pow(i/13,1.65)*(s.height-horizon);
      c.drawLine(Offset(s.width*.32-(y-horizon)*.002,s.height-y+horizon),
        Offset(s.width*.68+(y-horizon)*.002,s.height-y+horizon),grid);
    }
  }
  @override bool shouldRepaint(covariant CustomPainter oldDelegate)=>false;
}

class Logo extends StatelessWidget {
  final double size;
  const Logo({super.key,this.size=54});
  @override
  Widget build(BuildContext context)=>Text('STEX',
    style: TextStyle(fontSize:size,fontWeight:FontWeight.w900,letterSpacing:8,
      color:Colors.white,
      shadows:[Shadow(color:const Color(0xFF00F5FF).withOpacity(.8),blurRadius:22)]));
}

class GlowButton extends StatelessWidget {
  final String label; final VoidCallback onTap; final bool primary;
  const GlowButton({super.key,required this.label,required this.onTap,this.primary=true});
  @override
  Widget build(BuildContext context)=>GestureDetector(
    onTap:onTap,
    child: Container(
      width:230,height:58,alignment:Alignment.center,
      decoration:BoxDecoration(
        borderRadius:BorderRadius.circular(18),
        gradient: primary ? const LinearGradient(colors:[Color(0xFF00F5FF),Color(0xFF087BFF)])
          : null,
        border: primary?null:Border.all(color:const Color(0xFF00E5FF).withOpacity(.55)),
        boxShadow:[BoxShadow(color:const Color(0xFF00E5FF).withOpacity(primary?.18: .08),blurRadius:24,spreadRadius:1)],
      ),
      child:Text(label,style:TextStyle(fontSize:16,fontWeight:FontWeight.w900,letterSpacing:2,
        color:primary?Colors.black:Colors.white)),
    ),
  );
}

class HomeScreen extends StatelessWidget {
  final int best; final VoidCallback onPlay,onHelp,onSettings;
  const HomeScreen({super.key,required this.best,required this.onPlay,required this.onHelp,required this.onSettings});
  @override
  Widget build(BuildContext context)=>Scaffold(
    body:NeonBackdrop(child:SafeArea(child:Column(
      children:[
        const Spacer(flex:2),
        const Logo(size:62),
        const SizedBox(height:10),
        Text('RUN RIYADH. DODGE THE FUTURE.',
          style:TextStyle(color:Color(0xFF7FEFFF),fontSize:11,fontWeight:FontWeight.w700,letterSpacing:2.2)),
        const Spacer(),
        Container(padding:const EdgeInsets.symmetric(horizontal:18,vertical:12),
          decoration:BoxDecoration(color:Colors.black.withOpacity(.25),borderRadius:BorderRadius.circular(16),
            border:Border.all(color:Colors.white.withOpacity(.08))),
          child:Column(children:[
            Text('BEST SCORE',style:TextStyle(fontSize:10,letterSpacing:2,color:Colors.white.withOpacity(.6))),
            const SizedBox(height:3), Text('$best',style:const TextStyle(fontSize:28,fontWeight:FontWeight.w900)),
          ])),
        const SizedBox(height:22),
        GlowButton(label:'PLAY',onTap:onPlay),
        const SizedBox(height:12),
        Row(mainAxisAlignment:MainAxisAlignment.center,children:[
          TextButton(onPressed:onHelp,child:const Text('HOW TO PLAY')),
          const SizedBox(width:12),
          TextButton(onPressed:onSettings,child:const Text('SETTINGS')),
        ]),
        const Spacer(flex:2),
      ],
    ))));
}

class GameScreen extends StatefulWidget {
  final int best; final VoidCallback onPause; final ValueChanged<int> onGameOver;
  const GameScreen({super.key,required this.best,required this.onPause,required this.onGameOver});
  @override State<GameScreen> createState()=>_GameScreenState();
}

class _GameScreenState extends State<GameScreen> with SingleTickerProviderStateMixin {
  late AnimationController ticker;
  final List<Obstacle> obstacles=[];
  double playerY=0, vy=0, world=0, speed=0.34;
  int lane=1, score=0, distance=0;
  bool ready=false, dead=false;
  Offset? down;
  double spawn=0;

  @override void initState(){
    super.initState();
    ticker=AnimationController(vsync:this,duration:const Duration(days:1))
      ..addListener(_tick)..repeat();
    Future.delayed(const Duration(milliseconds:450),()=>setState(()=>ready=true));
  }
  @override void dispose(){ticker.dispose();super.dispose();}

  void _tick(){
    if(!mounted||!ready||dead)return;
    const dt=.016;
    setState((){
      world+=speed*dt;
      distance=(world*100).floor();
      score=distance;
      speed=math.min(.82,.34+distance/6500);
      playerY+=vy*dt; vy-=2.6*dt;
      if(playerY<0){playerY=0;vy=0;}
      spawn-=dt;
      if(spawn<=0){
        obstacles.add(Obstacle(lane:math.Random().nextInt(3),z:1.0,
          type:math.Random().nextBool()?0:1));
        spawn=math.max(.38,1.0-speed*.75);
      }
      for(final o in obstacles)o.z-=speed*dt;
      obstacles.removeWhere((o)=>o.z<-.1);
      for(final o in obstacles){
        if(o.z<.105&&o.z>.0&&o.lane==lane&&playerY<.22){
          dead=true;
          ticker.stop();
          widget.onGameOver(score);
          break;
        }
      }
    });
  }

  void jump(){if(playerY==0){vy=1.18;}}
  void laneMove(int dir){lane=(lane+dir).clamp(0,2);}

  @override Widget build(BuildContext context){
    return Scaffold(body:GestureDetector(
      behavior:HitTestBehavior.opaque,
      onTap:jump,
      onPanStart:(d)=>down=d.globalPosition,
      onPanEnd:(d){
        final p=down;if(p==null)return;
        final dx=d.globalPosition.dx-p.dx;
        if(dx.abs()>28)laneMove(dx>0?1:-1);
      },
      child:Stack(children:[
        CustomPaint(painter:GamePainter(world:world,playerY:playerY,lane:lane,obstacles:obstacles),size:Size.infinite),
        SafeArea(child:Padding(padding:const EdgeInsets.all(16),child:Row(
          crossAxisAlignment:CrossAxisAlignment.start,
          children:[
            _HudStat(label:'SCORE',value:'$score'),
            const SizedBox(width:18), _HudStat(label:'DIST',value:'${distance}m'),
            const Spacer(),
            IconButton(onPressed:widget.onPause,icon:const Icon(Icons.pause_rounded,color:Colors.white,size:28)),
          ]))),
        if(!ready)const Center(child:Countdown()),
      ]),
    ));
  }
}

class Countdown extends StatefulWidget{const Countdown({super.key});@override State<Countdown> createState()=>_CountdownState();}
class _CountdownState extends State<Countdown>{
  int n=3;
  @override void initState(){super.initState();_go();}
  Future<void>_go()async{for(int i=3;i>=1;i--){if(!mounted)return;setState(()=>n=i);await Future.delayed(const Duration(milliseconds:520));}if(mounted)setState(()=>n=0);}
  @override Widget build(BuildContext c)=>Text(n==0?'RUN':'$n',style:const TextStyle(fontSize:52,fontWeight:FontWeight.w900,letterSpacing:6,
    shadows:[Shadow(color:Color(0xFF00F5FF),blurRadius:28)]));
}

class _HudStat extends StatelessWidget{
  final String label,value;const _HudStat({required this.label,required this.value});
  @override Widget build(BuildContext c)=>Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
    Text(label,style:TextStyle(fontSize:9,letterSpacing:2,color:Colors.white.withOpacity(.55))),
    Text(value,style:const TextStyle(fontSize:22,fontWeight:FontWeight.w900)),
  ]);
}

class Obstacle{int lane;double z;int type;Obstacle({required this.lane,required this.z,required this.type});}

class GamePainter extends CustomPainter{
  final double world,playerY;final int lane;final List<Obstacle> obstacles;
  GamePainter({required this.world,required this.playerY,required this.lane,required this.obstacles});
  @override void paint(Canvas c,Size s){
    final p=Paint();
    p.shader=LinearGradient(begin:Alignment.topCenter,end:Alignment.bottomCenter,
      colors:const[Color(0xFF040818),Color(0xFF071B2D),Color(0xFF02040A)]).createShader(Offset.zero& s);
    c.drawRect(Offset.zero&s,p);
    final horizon=s.height*.56;
    // distant city
    final city=Paint()..color=const Color(0xFF091323);
    for(int i=0;i<18;i++){final x=i*s.width/18;final h=35+(i*37%110);c.drawRect(Rect.fromLTWH(x,horizon-h,28+(i%3)*10,h),city);}
    // road
    final road=Path()..moveTo(s.width*.18,s.height)..lineTo(s.width*.44,horizon)..lineTo(s.width*.56,horizon)..lineTo(s.width*.82,s.height)..close();
    c.drawPath(road,Paint()..color=const Color(0xFF070B12));
    final neon=Paint()..color=const Color(0xFF00D9FF).withOpacity(.45)..strokeWidth=2;
    c.drawLine(Offset(s.width*.18,s.height),Offset(s.width*.44,horizon),neon);
    c.drawLine(Offset(s.width*.82,s.height),Offset(s.width*.56,horizon),neon);
    for(int i=0;i<18;i++){
      final t=(i/18+world*.9)%1;
      final y=horizon+math.pow(t,1.9)*(s.height-horizon);
      final half=.04*s.width+.22*s.width*t;
      c.drawLine(Offset(s.width/2-half,y),Offset(s.width/2+half,y),Paint()..color=const Color(0xFF00D9FF).withOpacity(.16)..strokeWidth=1);
    }
    for(int l=0;l<3;l++){
      final xTop=s.width*(.44+.06*l), xBottom=s.width*(.18+.32*l);
      c.drawLine(Offset(xTop,horizon),Offset(xBottom,s.height),Paint()..color=const Color(0xFF4A6175).withOpacity(.25)..strokeWidth=1);
    }
    // obstacles
    for(final o in obstacles){
      final t=(1-o.z).clamp(0.0,1.0);
      final y=horizon+math.pow(t,1.7)*(s.height-horizon);
      final laneX=s.width*(.18+.32*o.lane);
      final w=38+82*t;
      final h=(o.type==0?42:74)*(0.55+0.7*t);
      final r=Rect.fromCenter(center:Offset(laneX,y-h/2),width:w,height:h);
      final glow=Paint()..color=const Color(0xFFFF286D).withOpacity(.22)..maskFilter=const MaskFilter.blur(BlurStyle.normal,12);
      c.drawRRect(RRect.fromRectAndRadius(r,Radius.circular(7)),glow);
      c.drawRRect(RRect.fromRectAndRadius(r,Radius.circular(7)),Paint()..color=const Color(0xFF160D1B));
      c.drawRRect(RRect.fromRectAndRadius(r.deflate(2),Radius.circular(5)),Paint()..style=PaintingStyle.stroke..strokeWidth=2..color=const Color(0xFFFF286D));
    }
    // player shadow
    final px=s.width*(.18+.32*lane);
    c.drawOval(Rect.fromCenter(center:Offset(px,s.height*.82),width:52,height:14),
      Paint()..color=Colors.black.withOpacity(.5));
    final py=s.height*.82-playerY*s.height*.27;
    // player glow
    c.drawCircle(Offset(px,py-20),28,Paint()..color=const Color(0xFF00F5FF).withOpacity(.12)..maskFilter=const MaskFilter.blur(BlurStyle.normal,14));
    final body=Paint()..color=Colors.white;
    c.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(px-13,py-42,26,35),Radius.circular(9)),body);
    c.drawCircle(Offset(px,py-51),10,Paint()..color=const Color(0xFFE7FBFF));
    c.drawLine(Offset(px-8,py-8),Offset(px-13,py+10),Paint()..color=const Color(0xFF00E5FF)..strokeWidth=5..strokeCap=StrokeCap.round);
    c.drawLine(Offset(px+8,py-8),Offset(px+13,py+10),Paint()..color=const Color(0xFF00E5FF)..strokeWidth=5..strokeCap=StrokeCap.round);
  }
  @override bool shouldRepaint(covariant GamePainter old)=>true;
}

class PauseScreen extends StatelessWidget{
  final VoidCallback onResume,onRestart,onHome,onSettings;
  const PauseScreen({super.key,required this.onResume,required this.onRestart,required this.onHome,required this.onSettings});
  @override Widget build(BuildContext c)=>Scaffold(body:NeonBackdrop(child:Center(child:Container(
    margin:const EdgeInsets.all(28),padding:const EdgeInsets.all(28),
    decoration:BoxDecoration(color:const Color(0xFF07101D).withOpacity(.86),borderRadius:BorderRadius.circular(28),
      border:Border.all(color:const Color(0xFF00E5FF).withOpacity(.2))),
    child:Column(mainAxisSize:MainAxisSize.min,children:[
      const Logo(size:42),const SizedBox(height:8),const Text('PAUSED',style:TextStyle(letterSpacing:4,fontWeight:FontWeight.w800)),
      const SizedBox(height:28),GlowButton(label:'RESUME',onTap:onResume),
      const SizedBox(height:10),GlowButton(label:'RESTART',onTap:onRestart,primary:false),
      const SizedBox(height:4),TextButton(onPressed:onSettings,child:const Text('SETTINGS')),
      TextButton(onPressed:onHome,child:const Text('HOME')),
    ]))));
}

class GameOverScreen extends StatelessWidget{
  final int score,distance,best;final VoidCallback onAgain,onHome;
  const GameOverScreen({super.key,required this.score,required this.distance,required this.best,required this.onAgain,required this.onHome});
  @override Widget build(BuildContext c)=>Scaffold(body:NeonBackdrop(child:Center(child:Padding(
    padding:const EdgeInsets.all(24),child:Column(mainAxisSize:MainAxisSize.min,children:[
      const Text('GAME OVER',style:TextStyle(fontSize:38,fontWeight:FontWeight.w900,letterSpacing:4,
        shadows:[Shadow(color:Color(0xFFFF286D),blurRadius:24)])),
      const SizedBox(height:24),
      Row(mainAxisAlignment:MainAxisAlignment.center,children:[
        _Result(label:'SCORE',value:'$score'),_Result(label:'DISTANCE',value:'${distance}m'),_Result(label:'BEST',value:'$best'),
      ]),
      const SizedBox(height:30),GlowButton(label:'PLAY AGAIN',onTap:onAgain),
      const SizedBox(height:10),GlowButton(label:'HOME',onTap:onHome,primary:false),
    ]))));
}
}
class _Result extends StatelessWidget{final String label,value;const _Result({required this.label,required this.value});
@override Widget build(BuildContext c)=>Padding(padding:const EdgeInsets.symmetric(horizontal:12),child:Column(children:[
Text(label,style:TextStyle(fontSize:9,letterSpacing:2,color:Colors.white.withOpacity(.55))),Text(value,style:const TextStyle(fontSize:25,fontWeight:FontWeight.w900))]));}

class HelpScreen extends StatelessWidget{
  final VoidCallback onBack;const HelpScreen({super.key,required this.onBack});
  @override Widget build(BuildContext c)=>Scaffold(body:NeonBackdrop(child:SafeArea(child:Padding(
    padding:const EdgeInsets.all(24),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      TextButton.icon(onPressed:onBack,icon:const Icon(Icons.arrow_back),label:const Text('BACK')),
      const SizedBox(height:18),const Logo(size:46),const SizedBox(height:24),
      const Text('HOW TO PLAY',style:TextStyle(fontSize:26,fontWeight:FontWeight.w900,letterSpacing:3)),
      const SizedBox(height:18),
      _HelpRow(icon:Icons.touch_app_rounded,title:'TAP TO JUMP',text:'Clear barriers and keep your momentum.'),
      _HelpRow(icon:Icons.swipe_rounded,title:'SWIPE LEFT / RIGHT',text:'Switch lanes instantly to dodge traffic.'),
      _HelpRow(icon:Icons.speed_rounded,title:'SURVIVE',text:'The city accelerates. Stay sharp as the pace rises.'),
      _HelpRow(icon:Icons.emoji_events_rounded,title:'BEAT YOUR SCORE',text:'Distance drives your score. Every run is a new record chase.'),
      const Spacer(),Center(child:GlowButton(label:'GOT IT',onTap:onBack)),
    ]))));
}
}
class _HelpRow extends StatelessWidget{final IconData icon;final String title,text;const _HelpRow({required this.icon,required this.title,required this.text});
@override Widget build(BuildContext c)=>Padding(padding:const EdgeInsets.only(bottom:22),child:Row(crossAxisAlignment:CrossAxisAlignment.start,children:[
Container(width:48,height:48,decoration:BoxDecoration(borderRadius:BorderRadius.circular(14),color:const Color(0xFF00E5FF).withOpacity(.08),border:Border.all(color:const Color(0xFF00E5FF).withOpacity(.2))),child:Icon(icon,color:const Color(0xFF00E5FF))),
const SizedBox(width:14),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
Text(title,style:const TextStyle(fontWeight:FontWeight.w900,letterSpacing:1.4)),const SizedBox(height:4),Text(text,style:TextStyle(color:Colors.white.withOpacity(.62),height:1.35))]))]));}

class SettingsScreen extends StatelessWidget{
  final VoidCallback onBack;const SettingsScreen({super.key,required this.onBack});
  @override Widget build(BuildContext c)=>Scaffold(body:NeonBackdrop(child:SafeArea(child:Padding(
    padding:const EdgeInsets.all(24),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      TextButton.icon(onPressed:onBack,icon:const Icon(Icons.arrow_back),label:const Text('BACK')),
      const SizedBox(height:18),const Logo(size:46),const SizedBox(height:24),
      const Text('SETTINGS',style:TextStyle(fontSize:26,fontWeight:FontWeight.w900,letterSpacing:3)),
      const SizedBox(height:18),_SettingTile(title:'HAPTICS',subtitle:'Ready for production haptic feedback',icon:Icons.vibration),
      _SettingTile(title:'SOUND',subtitle:'Audio system placeholder',icon:Icons.graphic_eq),
      _SettingTile(title:'QUALITY',subtitle:'Optimized real-time painter rendering',icon:Icons.auto_awesome),
      const Spacer(),Center(child:GlowButton(label:'DONE',onTap:onBack)),
    ]))));
}
}
class _SettingTile extends StatelessWidget{final String title,subtitle;final IconData icon;const _SettingTile({required this.title,required this.subtitle,required this.icon});
@override Widget build(BuildContext c)=>Container(margin:const EdgeInsets.only(bottom:10),padding:const EdgeInsets.all(16),
decoration:BoxDecoration(color:Colors.white.withOpacity(.035),borderRadius:BorderRadius.circular(16),border:Border.all(color:Colors.white.withOpacity(.07))),
child:Row(children:[Icon(icon,color:const Color(0xFF00E5FF)),const SizedBox(width:14),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
Text(title,style:const TextStyle(fontWeight:FontWeight.w800)),Text(subtitle,style:TextStyle(fontSize:11,color:Colors.white.withOpacity(.48)))])),
const Icon(Icons.chevron_right,color:Colors.white24)]));}
