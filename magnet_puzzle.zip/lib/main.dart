
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';

const bg = Color(0xFF0B1020);
const panel = Color(0xFF151C32);
const accent = Color(0xFF7C5CFF);
const cyan = Color(0xFF36D1DC);
const pink = Color(0xFFFF5EA8);
const green = Color(0xFF42E695);
const yellow = Color(0xFFFFD166);

TextStyle titleStyle(double size) => GoogleFonts.poppins(
  fontSize: size, fontWeight: FontWeight.w800, color: Colors.white,
);
TextStyle bodyStyle(double size) => GoogleFonts.poppins(
  fontSize: size, fontWeight: FontWeight.w500, color: Colors.white70,
);

class GameShell extends StatelessWidget {
  final String title;
  final String subtitle;
  final Widget child;
  final VoidCallback? onReset;
  const GameShell({super.key, required this.title, required this.subtitle, required this.child, this.onReset});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bg,
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 560),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(18, 16, 18, 18),
              child: Column(
                children: [
                  Row(children: [
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(title, style: titleStyle(26)),
                      const SizedBox(height: 2),
                      Text(subtitle, style: bodyStyle(12)),
                    ])),
                    if (onReset != null) IconButton(
                      onPressed: onReset,
                      icon: const Icon(Icons.refresh_rounded, color: Colors.white70),
                    )
                  ]),
                  const SizedBox(height: 14),
                  Expanded(child: child),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class StatPill extends StatelessWidget {
  final String label;
  final String value;
  const StatPill({super.key, required this.label, required this.value});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 9),
    decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(16)),
    child: Column(children: [
      Text(value, style: titleStyle(18)),
      Text(label, style: bodyStyle(10)),
    ]),
  );
}

Future<void> saveInt(String key, int value) async {
  final p = await SharedPreferences.getInstance();
  await p.setInt(key, value);
}
Future<int> loadInt(String key) async {
  final p = await SharedPreferences.getInstance();
  return p.getInt(key) ?? 0;
}

void main()=>runApp(const MagnetApp());
class MagnetApp extends StatelessWidget{const MagnetApp({super.key});@override Widget build(BuildContext c)=>MaterialApp(debugShowCheckedModeBanner:false,theme:ThemeData.dark(useMaterial3:true),home:const MagnetGame());}
class _MagnetGameState extends State<MagnetGame>{
 int level=1,moves=0; List<Offset> pos=[]; final targets=[const Offset(.2,.25),const Offset(.8,.75),const Offset(.25,.75)];
 @override void initState(){super.initState();_reset();}
 void _reset(){pos=[const Offset(.75,.25),const Offset(.55,.55),const Offset(.45,.35)];moves=0;}
 void _move(int i,Offset p){setState((){pos[i]=Offset(p.dx.clamp(.1,.9),p.dy.clamp(.12,.88));moves++;});}
 @override Widget build(BuildContext c)=>GameShell(title:'Magnet Puzzle',subtitle:'Drag each colored magnet onto its matching target.',onReset:()=>setState(_reset),child:Column(children:[
 Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[StatPill(label:'Level',value:'$level'),StatPill(label:'Moves',value:'$moves')]),const SizedBox(height:14),
 Expanded(child:LayoutBuilder(builder:(c,box){final s=min(box.maxWidth,box.maxHeight);return Center(child:SizedBox(width:s,height:s,child:Container(decoration:BoxDecoration(color:panel,borderRadius:BorderRadius.circular(28)),child:Stack(children:[
 for(int i=0;i<targets.length;i++)Positioned(left:targets[i].dx*s-26,top:targets[i].dy*s-26,child:Container(width:52,height:52,decoration:BoxDecoration(shape:BoxShape.circle,border:Border.all(color:[pink,cyan,yellow][i],width:2),color:[pink,cyan,yellow][i].withOpacity(.08)),child:Center(child:Text('◎',style:titleStyle(24).copyWith(color:[pink,cyan,yellow][i]))))),
 for(int i=0;i<pos.length;i++)Positioned(left:pos[i].dx*s-25,top:pos[i].dy*s-25,child:GestureDetector(onPanUpdate:(d){final local=(context.findRenderObject() as RenderBox).globalToLocal(d.globalPosition);_move(i,Offset(local.dx/s,local.dy/s));},child:Container(width:50,height:50,decoration:BoxDecoration(shape:BoxShape.circle,color:[pink,cyan,yellow][i],boxShadow:[BoxShadow(color:[pink,cyan,yellow][i].withOpacity(.45),blurRadius:14)]),child:const Icon(Icons.bolt_rounded,color:Colors.black,size:28))))),
])));}),),
 const SizedBox(height:10),Text('Match the rings to win',style:bodyStyle(13))
 ]));}
