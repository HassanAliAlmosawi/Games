
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';

const bg = Color(0xFF0B1020);
const panel = Color(0xFF151C32);
const accent = Color(0xFF7C5CFF);
const cyan = Color(0xFF36D1DC);
const pink = Color(0xFFFF5EA8);
const green = Color(0xFF42E695);
const yellow = Color(0xFFFFD166);

TextStyle titleStyle(double size) => GoogleFonts.poppins(
  fontSize: size, fontWeight: FontWeight.w800, color: Colors.white,
);
TextStyle bodyStyle(double size) => GoogleFonts.poppins(
  fontSize: size, fontWeight: FontWeight.w500, color: Colors.white70,
);

class GameShell extends StatelessWidget {
  final String title;
  final String subtitle;
  final Widget child;
  final VoidCallback? onReset;
  const GameShell({super.key, required this.title, required this.subtitle, required this.child, this.onReset});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bg,
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 560),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(18, 16, 18, 18),
              child: Column(
                children: [
                  Row(children: [
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(title, style: titleStyle(26)),
                      const SizedBox(height: 2),
                      Text(subtitle, style: bodyStyle(12)),
                    ])),
                    if (onReset != null) IconButton(
                      onPressed: onReset,
                      icon: const Icon(Icons.refresh_rounded, color: Colors.white70),
                    )
                  ]),
                  const SizedBox(height: 14),
                  Expanded(child: child),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class StatPill extends StatelessWidget {
  final String label;
  final String value;
  const StatPill({super.key, required this.label, required this.value});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 9),
    decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(16)),
    child: Column(children: [
      Text(value, style: titleStyle(18)),
      Text(label, style: bodyStyle(10)),
    ]),
  );
}

Future<void> saveInt(String key, int value) async {
  final p = await SharedPreferences.getInstance();
  await p.setInt(key, value);
}
Future<int> loadInt(String key) async {
  final p = await SharedPreferences.getInstance();
  return p.getInt(key) ?? 0;
}

void main() => runApp(const SortFactoryApp());
class SortFactoryApp extends StatelessWidget {
  const SortFactoryApp({super.key});
  @override Widget build(BuildContext context) => MaterialApp(debugShowCheckedModeBanner:false, theme:ThemeData.dark(useMaterial3:true), home:const SortGame());
}
class SortGame extends StatefulWidget { const SortGame({super.key}); @override State<SortGame> createState()=>_SortGameState(); }
class Item { final int type; final IconData icon; const Item(this.type,this.icon); }
class _SortGameState extends State<SortGame> {
  final types=[Colors.orange, Colors.lightBlue, Colors.pinkAccent];
  final icons=[Icons.apple_rounded, Icons.star_rounded, Icons.diamond_rounded];
  List<Item> items=[]; int score=0, combo=0, target=10; int best=0;
  @override void initState(){super.initState(); _newLevel(); loadInt('sort_best').then((v)=>setState(()=>best=v));}
  void _newLevel(){ final r=Random(); items=List.generate(target,(i)=>Item(r.nextInt(3),icons[r.nextInt(3)])); /* make target distribution useful */ }
  void _tap(int index,int bin){
    final item=items[index];
    if(item.type==bin){ setState(()=>items.removeAt(index)); combo++; score += 10+combo*2;
      if(items.isEmpty){ score+=100; if(score>best){best=score;saveInt('sort_best',best);} target=min(18,target+1); _newLevel(); }
    } else { setState(()=>combo=0); }
  }
  @override Widget build(BuildContext context)=>GameShell(title:'Sort Factory',subtitle:'Drag is optional — tap an item, then choose its destination.',onReset:()=>setState(() {score=0;combo=0;target=10;_newLevel();}),child:
    Column(children:[
      Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[StatPill(label:'Score',value:'$score'),StatPill(label:'Best',value:'$best'),StatPill(label:'Combo',value:'x$combo')]),
      const SizedBox(height:16),
      Expanded(child:GridView.builder(gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:3,crossAxisSpacing:10,mainAxisSpacing:10),itemCount:items.length,itemBuilder:(c,i){
        final it=items[i]; return GestureDetector(onTap:(){_showBins(i);},child:Container(decoration:BoxDecoration(color:types[it.type].withOpacity(.16),borderRadius:BorderRadius.circular(22),border:Border.all(color:types[it.type].withOpacity(.35))),child:Icon(it.icon,color:types[it.type],size:40)));
      })),
      Text('Choose the correct bin',style:bodyStyle(13)),
      const SizedBox(height:8),
      Row(children:List.generate(3,(b)=>Expanded(child:Padding(padding:const EdgeInsets.symmetric(horizontal:4),child:Container(height:60,decoration:BoxDecoration(color:types[b].withOpacity(.18),borderRadius:BorderRadius.circular(18)),child:Center(child:Icon(icons[b],color:types[b],size:28))))))),
      const SizedBox(height:8),
    ]));
  void _showBins(int i){showModalBottomSheet(context:context,backgroundColor:panel,shape:const RoundedRectangleBorder(borderRadius:BorderRadius.vertical(top:Radius.circular(26))),builder:(c)=>SafeArea(child:Padding(padding:const EdgeInsets.all(18),child:Row(children:List.generate(3,(b)=>Expanded(child:Padding(padding:const EdgeInsets.all(5),child:ElevatedButton(style:ElevatedButton.styleFrom(backgroundColor:types[b].withOpacity(.2),foregroundColor:types[b],padding:const EdgeInsets.all(18)),onPressed:(){Navigator.pop(c);_tap(i,b);},child:Icon(icons[b],size:28)))))))));}
}
