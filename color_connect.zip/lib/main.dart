
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';

const bg = Color(0xFF0B1020);
const panel = Color(0xFF151C32);
const accent = Color(0xFF7C5CFF);
const cyan = Color(0xFF36D1DC);
const pink = Color(0xFFFF5EA8);
const green = Color(0xFF42E695);
const yellow = Color(0xFFFFD166);

TextStyle titleStyle(double size) => GoogleFonts.poppins(
  fontSize: size, fontWeight: FontWeight.w800, color: Colors.white,
);
TextStyle bodyStyle(double size) => GoogleFonts.poppins(
  fontSize: size, fontWeight: FontWeight.w500, color: Colors.white70,
);

class GameShell extends StatelessWidget {
  final String title;
  final String subtitle;
  final Widget child;
  final VoidCallback? onReset;
  const GameShell({super.key, required this.title, required this.subtitle, required this.child, this.onReset});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bg,
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 560),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(18, 16, 18, 18),
              child: Column(
                children: [
                  Row(children: [
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(title, style: titleStyle(26)),
                      const SizedBox(height: 2),
                      Text(subtitle, style: bodyStyle(12)),
                    ])),
                    if (onReset != null) IconButton(
                      onPressed: onReset,
                      icon: const Icon(Icons.refresh_rounded, color: Colors.white70),
                    )
                  ]),
                  const SizedBox(height: 14),
                  Expanded(child: child),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class StatPill extends StatelessWidget {
  final String label;
  final String value;
  const StatPill({super.key, required this.label, required this.value});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 9),
    decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(16)),
    child: Column(children: [
      Text(value, style: titleStyle(18)),
      Text(label, style: bodyStyle(10)),
    ]),
  );
}

Future<void> saveInt(String key, int value) async {
  final p = await SharedPreferences.getInstance();
  await p.setInt(key, value);
}
Future<int> loadInt(String key) async {
  final p = await SharedPreferences.getInstance();
  return p.getInt(key) ?? 0;
}

void main()=>runApp(const ConnectApp());
class ConnectApp extends StatelessWidget{const ConnectApp({super.key});@override Widget build(BuildContext c)=>MaterialApp(debugShowCheckedModeBanner:false,theme:ThemeData.dark(useMaterial3:true),home:const ConnectGame());}
class _ConnectState extends State<ConnectGame>{final n=6;List<List<int>> board=[];int moves=0,level=1;@override void initState(){super.initState();_reset();}
void _reset(){final r=Random(level);board=List.generate(n,(_)=>List.generate(n,(_)=>r.nextInt(4)));moves=0;}
@override Widget build(BuildContext c)=>GameShell(title:'Color Connect',subtitle:'Tap two matching colors to connect them.',onReset:()=>setState(_reset),child:Column(children:[Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[StatPill(label:'Level',value:'$level'),StatPill(label:'Moves',value:'$moves')]),const SizedBox(height:14),Expanded(child:GridView.builder(physics:const NeverScrollableScrollPhysics(),gridDelegate:SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:n,crossAxisSpacing:6,mainAxisSpacing:6),itemCount:n*n,itemBuilder:(c,i){final v=board[i~/n][i%n];final colors=[pink,cyan,yellow,green];return GestureDetector(onTap:()=>setState(()=>moves++),child:Container(decoration:BoxDecoration(color:colors[v].withOpacity(.17),borderRadius:BorderRadius.circular(14)),child:Center(child:Container(width:25,height:25,decoration:BoxDecoration(shape:BoxShape.circle,color:colors[v],boxShadow:[BoxShadow(color:colors[v].withOpacity(.4),blurRadius:10)])))));})),const SizedBox(height:10),Text('Prototype mechanic — expand into path drawing',style:bodyStyle(12))]));}
class ConnectGame extends StatefulWidget{const ConnectGame({super.key});@override State<ConnectGame> createState()=>_ConnectState();}
